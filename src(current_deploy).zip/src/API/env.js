export const API_URL = process.env.API_URL ||  'http://localhost:9090/api/v1'
export const SERVER_URL = process.env.SERVER_URL || 'http://localhost:9090'
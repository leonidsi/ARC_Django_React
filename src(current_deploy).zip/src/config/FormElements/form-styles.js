 const styles = {
    marginBtn: {
        marginLeft: 8
    },
    formItemMargin: {
        marginTop: 20
    },
    addButton: {
        marginLeft: 10,
        marginBottom: 10,
        marginTop: 10,
    }
}
export default styles
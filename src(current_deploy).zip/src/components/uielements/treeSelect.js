import { TreeSelect } from 'antd';

export default TreeSelect;